#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

void printMatrix(const vector<vector<int>>& matrix) {
    for (const auto& row : matrix) {
        for (int val : row) {
            cout << val << "\t";
        }
        cout << endl;
    }
}

void floyd(const vector<vector<int>>& graph, int n) {
    vector<vector<int>> dist(graph);
    vector<vector<int>> next(n, vector<int>(n, -1));

    // Floyd-Warshall algorithm
    for (int k = 0; k < n; ++k) {
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                if (dist[i][k] + dist[k][j] < dist[i][j]) {
                    dist[i][j] = dist[i][k] + dist[k][j];
                    next[i][j] = k;
                }
            }
        }
    }

    // Print results
    cout << "Pmatrix:" << endl;
    printMatrix(dist);

    for (int i = 0; i < n; ++i) {
        cout << endl << "V" << (i+1) << "-Vj: shortest path and length" << endl;
        for (int j = 0; j < n; ++j) {
            if (i != j) {
                cout << "V" << (i+1) << " V" << (j+1) << ": " << dist[i][j];
                // Print path if it exists
                int next_node = next[i][j];
                while (next_node != -1) {
                    cout << " V" << (next_node+1);
                    next_node = next[next_node][j];
                }
                cout << endl;
            } else {
                cout << "V" << (i+1) << " V" << (j+1) << ": 0" << endl;
            }
        }
    }
}

int main(int argc, char* argv[]) {
    if (argc != 2) {
        cerr << "Usage: " << argv[0] << " <graph-file>" << endl;
        return 1;
    }

    ifstream file(argv[1]);
    if (!file) {
        cerr << "Error: Unable to open file " << argv[1] << endl;
        return 1;
    }

    int nProblems = 0;
    while (!file.eof()) {
        string line;
        getline(file, line);
        if (!line.empty() && line.find("n =") != string::npos) {
            nProblems++;
        }
    }
    file.clear();
    file.seekg(0, ios::beg);

    int n;
    while (file >> n) {
        cout << "Problem " << (nProblems - 1) << ": n = " << n << endl;

        vector<vector<int>> graph(n, vector<int>(n));
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                file >> graph[i][j];
            }
        }

        floyd(graph, n);
    }

    cout << "Total number of problems: " << nProblems << endl;

    return 0;
}
